﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNETFirstProject
{
    public partial class Form2 : Form
    {
        Product secilenUrun;
        public Form2()
        {
            InitializeComponent();
        }

        public Form2(Product gelenSeciliUrun)
        {
            InitializeComponent();
            secilenUrun = gelenSeciliUrun;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            lblFiyat.Text = secilenUrun.Fiyat.ToString();
            lblSiparistekiAdet.Text = secilenUrun.SiparistekiAdet.ToString();
            lblStok.Text = secilenUrun.Stok.ToString();
            lblUrunAdi.Text = secilenUrun.UrunAdi.ToString();
            lblUrunId.Text = secilenUrun.ProductId.ToString();
        }
    }
}
