﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNETFirstProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection cnn = new SqlConnection(Properties.Settings.Default.NorthwindCS);
            try
            {
                if (cnn.State == ConnectionState.Closed)
                {
                    cnn.Open();
                }

                string sorgu = "select * from Categories";
                SqlCommand cmd = new SqlCommand(sorgu, cnn);
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Category c = new Category();
                        c.categoryId = Convert.ToInt32(reader["CategoryID"]);
                        c.CatName = reader["CategoryName"].ToString();
                        c.Aciklama = reader["Description"].ToString();
                        lstCategories.Items.Add(c);
                    }
                }                
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (cnn.State == ConnectionState.Open)
                {
                    cnn.Close();
                }
            }
        }

        private void lstCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            Category secilenKategori = (Category)lstCategories.SelectedItem;
            SqlConnection cnn = new SqlConnection(Properties.Settings.Default.NorthwindCS);

            using (cnn)
            {
                string sorgu = "select * from Products where CategoryID =" + secilenKategori.categoryId.ToString();

                SqlCommand cmd = new SqlCommand(sorgu, cnn);
                cnn.Open();

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    listView1.Items.Clear();
                    while (dr.Read())
                    {
                        Product p = new Product();
                        p.ProductId = Convert.ToInt32(dr["ProductID"]);
                        p.UrunAdi = dr["ProductName"].ToString();
                        p.Fiyat = Convert.ToDecimal(dr["UnitPrice"]);
                        p.Stok = Convert.ToInt32(dr["UnitsInStock"]);
                        p.SiparistekiAdet = Convert.ToInt32(dr["UnitsOnOrder"]);

                        ListViewItem li = new ListViewItem();
                        li.Text = p.UrunAdi;
                        li.SubItems.Add(p.Fiyat.ToString());
                        li.SubItems.Add(p.Stok.ToString());
                        li.SubItems.Add(p.SiparistekiAdet.ToString());
                        li.Tag = p;

                        listView1.Items.Add(li);

                    }
                }
            }

        }

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {

            Product secilenUrun = listView1.FocusedItem.Tag as Product;
            Form2 frm2 = new Form2(secilenUrun);
            frm2.ShowDialog();

            /*
           
            if (listView1.FocusedItem != null)
            {
                ListViewItem secilen = listView1.FocusedItem;
                tag = Convert.ToInt32(secilen.Tag);
                Form2 frm2 = new Form2(tag);
            }
            */


        }
    }
}
